﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeasuringDevice.Units
{
    public enum Units
    {
        Metric = 0,
        Imperial = 1
    }
}
